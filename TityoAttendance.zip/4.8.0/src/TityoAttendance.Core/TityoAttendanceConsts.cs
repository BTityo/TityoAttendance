﻿namespace TityoAttendance
{
    public class TityoAttendanceConsts
    {
        public const string LocalizationSourceName = "TityoAttendance";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
